from flask import Blueprint
from ..app import *
user = Blueprint('user', __name__)


from ..model.user import  User, user_schema, Friend, friend_schema, friends_schema



#Create a new user
@app.route('/newuser', methods=['POST'])
def create_user():
    
        user_name = request.json['user_name']
        password = request.json['password']
        
        user = User(user_name=user_name, password=password)
        
        db.session.add(user)
        db.session.commit()
        
        return jsonify(user_schema.dump(user))
    
    

#login as existing user    
@app.route('/authenticate', methods=['POST'])
def authenticate():
        
    user_name = request.json.get('user_name')
    password = request.json.get('password')
        
    if not user_name or not password:
        abort(400)
            
    user = User.query.filter_by(user_name=user_name).first()
        
    if not user:
        return jsonify({'error': 'Incorrect username or password'}), 401
            
    if user and bcrypt.check_password_hash(user.hashed_password, password):
        return jsonify({'token': create_token(user.id)})
            
    else:
        return jsonify({'error': 'Incorrect username or password'}), 401

            

#Friend Management APIS

#Get all friends of an authenticated user
@app.route('/users/friends', methods=['GET'])
def get_friends():
    
    if extract_auth_token(request):
        
        if decode_token(extract_auth_token(request)):
            
            user_id = decode_token(extract_auth_token(request))
            
            if not user_id:
                
                abort(403)
            #handle the case for whether the request was sent by the user or by the friend
            friends = Friend.query.filter(or_(Friend.user_id==user_id, Friend.friend_id==user_id), Friend.status=='accepted').all()
            friend_ids = [friend.friend_id if friend.user_id==user_id else friend.user_id for friend in friends]
            friends = User.query.filter(User.id.in_(friend_ids)).all()
            
            return friends_schema.jsonify(friends)
     

    else:
        abort(401, 'Authentication token is missing or invalid.')
    
   


#Send a friend request to a user
@app.route('/users/add_friend', methods=['POST'])
def add_friend():
    
    if extract_auth_token(request):
        
        if decode_token(extract_auth_token(request)):
            
            user_id = decode_token(extract_auth_token(request))
            
            if not user_id:
                
                abort(403)
                
            friend_name = request.json['friend_name']
            friend = User.query.filter_by(user_name=friend_name).first()
            
            if not friend:
                
                return jsonify({'message': 'Friend not found'}), 404
            
        existing_friendship = Friend.query.filter_by(user_id=user_id, friend_id=friend.id).first()
        
        if existing_friendship:
            
            return jsonify({'message': 'Friend request already sent'}), 400
        
        new_friend = Friend(user_id, friend.id, 'pending')
        db.session.add(new_friend)
        db.session.commit()
    
    else:
        
        abort(401, 'Authentication token is missing or invalid.')
        
    return jsonify({'message': 'Friend request sent'}), 201





#Display outgoing and incoming friend requests
@app.route('/users/friend_requests', methods=['GET'])
def get_friend_requests():
    
    if extract_auth_token(request):
        
        if decode_token(extract_auth_token(request)):
            
            user_id = decode_token(extract_auth_token(request))
            
            if not user_id:
                
                abort(403)
                
        friend_data_incoming = db.session.query(User.id, User.user_name).\
            join(Friend, Friend.user_id == User.id).\
            filter(Friend.friend_id == user_id, Friend.status == 'pending').all()
        friend_data_incoming = [{'user_name': user_name, 'request_type': 'incoming'} for id, user_name in friend_data_incoming]
        friend_data_outgoing = db.session.query(User.id, User.user_name).\
            join(Friend, Friend.friend_id == User.id).\
            filter(Friend.user_id == user_id, Friend.status == 'pending').all()
            
        friend_data_outgoing = [{'user_name': user_name, 'request_type': 'outgoing'} for id, user_name in friend_data_outgoing]
        friend_data = friend_data_incoming + friend_data_outgoing
    
        return jsonify(friend_data)
    
    else:
        
        abort(401, 'Authentication token is missing or invalid.')



#Manage friend requests
@app.route('/users/request_action/<string:sender_name>', methods=['PUT'])
def accept_reject_friend(sender_name):
    
    if extract_auth_token(request):
        
        if decode_token(extract_auth_token(request)):
            
            user_id = decode_token(extract_auth_token(request))
            
            if not user_id:
                
                abort(403)
                
            sender = User.query.filter_by(user_name=sender_name).first()
            
            if not sender:
                
                return jsonify({'message': 'User not found'}), 404
            
            friend = Friend.query.filter_by(user_id=sender.id, friend_id=user_id).first()
            
            if not friend:
                
                return jsonify({'message': 'Friend request not found'}), 404
            # Check if the current user is the recipient of the friend request
            if friend.friend_id == user_id:
                
                if 'status' not in request.json:
                    
                    return jsonify({'message': 'Missing status parameter'}), 400
                
                status = request.json['status']
                
                if status not in ['accepted', 'rejected']:
                    
                    return jsonify({'message': 'Invalid status parameter'}), 400
                
                friend.status = status
                #delete friend request record from the friend table in case of rejection
                if status == 'rejected':
                    
                    db.session.delete(friend)
                    
                db.session.commit()
                
                return jsonify({'message': 'Friend request {} successfully'.format(status)}), 200
            
            else:
                
                return jsonify({'message': 'You are not authorized to perform this action'}), 403
            
    else:
        
        abort(401, 'Authentication token is missing or invalid.')


#Remove friend
@app.route('/users/remove_friend/<int:friend_id>', methods=['DELETE'])
def remove_friend(friend_id):
    
    if extract_auth_token(request):
        
        if decode_token(extract_auth_token(request)):
            
            user_id = decode_token(extract_auth_token(request))
            
            if not user_id:
                
                abort(403)
    

        #handle the case for if the user was the sender or the receiver of the request inside the query
        friend = Friend.query.filter(
            ((Friend.user_id == user_id) & (Friend.friend_id == friend_id)) | 
            ((Friend.user_id == friend_id) & (Friend.friend_id == user_id))
        ).first()
        
        
        if not friend:
            
            return jsonify({'message': 'Friend not found'}), 404
        
        db.session.delete(friend)
        db.session.commit()
        
        return jsonify({'message': 'Friend removed'}), 200
    
    else:
        
        abort(401, 'Authentication token is missing or invalid.')
        
        
        
#Fetch all users that are not friends with the current user
@app.route('/users/nonfriends', methods=['GET'])
def get_non_friend_users():
    
    if extract_auth_token(request):
                
        if decode_token(extract_auth_token(request)):
            
            user_id = decode_token(extract_auth_token(request))
            
            if not user_id:
                
                abort(403)  


             # Fetch users who are not friends with the current user
            friends_subquery = db.session.query(Friend.user_id).filter(Friend.friend_id == user_id).union(
                            db.session.query(Friend.friend_id).filter(Friend.user_id == user_id)).subquery()

            non_friend_users = User.query.filter(User.id != user_id, User.id.notin_(friends_subquery.select())).all()


           
            result = [{"id": user.id, "user_name": user.user_name} for user in non_friend_users]

            return jsonify(result), 200
        