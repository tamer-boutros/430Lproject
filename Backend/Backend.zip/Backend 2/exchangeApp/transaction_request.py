from flask import Blueprint
from ..app import *
transaction_request = Blueprint('transaction_request', __name__)


from ..model.transaction import Transaction, TransactionRequestSchema, TransactionRequests, transaction_schema, transaction_request_schema, transaction_requests_schema

#Create transaction request
@app.route('/transaction_request', methods=['POST'])
def create_transaction_request():
    
    if extract_auth_token(request):
        
        if decode_token(extract_auth_token(request)):
            
            user_id = decode_token(extract_auth_token(request))
            
            if not user_id:
                
                abort(403)
            
            sender_id = user_id
            recipient_username = request.json['recipient_username']
            usd_amount = request.json.get('usd_amount')
            lbp_amount = request.json.get('lbp_amount')
            usd_to_lbp = request.json.get('usd_to_lbp')

            # Validate usd_amount and lbp_amount
            try:
                usd_amount = float(usd_amount)
                lbp_amount = float(lbp_amount)
                usd_to_lbp = int(usd_to_lbp)
                
                if usd_amount <= 0 or lbp_amount <= 0:
                    abort(400, 'usd_amount and lbp_amount must be positive')
                    
                if usd_to_lbp not in [0, 1]:
                    abort(400, 'usd_to_lbp must be a boolean (0 for false, 1 for true)')
            
            except (ValueError, TypeError):
                abort(400, 'usd_amount and lbp_amount must be floats')
    
            if not all([usd_amount, lbp_amount, usd_to_lbp]):
                abort(400, 'Invalid input data')
            
            if not (sender_id and recipient_username):
                
                return jsonify({'error': 'Invalid user ID(s)'}), 400
            
            # Check that sender and recipient are friends
            recipient = User.query.filter_by(user_name=recipient_username).first()
            
            if not recipient:
                
                return jsonify({'error': 'Recipient username not found'}), 400
            
            friendship = Friend.query.filter(
                or_(
                    and_(Friend.user_id == sender_id, Friend.friend_id == recipient.id),
                    and_(Friend.user_id == recipient.id, Friend.friend_id == sender_id)
                ),
                Friend.status == 'accepted'
            ).first()

            if not friendship:
                
                return jsonify({'error': 'Sender and recipient are not friends'}), 400
            
            # Create new transaction request object
            transaction_request = TransactionRequests(
                sender_id=sender_id,
                recipient_id=recipient.id,
                usd_amount=usd_amount,
                lbp_amount=lbp_amount,
                usd_to_lbp=usd_to_lbp
            )
            
            # Add transaction request object to database
            db.session.add(transaction_request)
            db.session.commit()
            
            return jsonify({'message': 'Transaction request created successfully'}), 201
        
    else:
        
        abort(401, 'Authentication token is missing or invalid.')


#fetch transaction requests
@app.route('/get_transaction_requests', methods=['GET'])
def get_transaction_requests():
        
    if extract_auth_token(request):
        
        if decode_token(extract_auth_token(request)):
            
            user_id = decode_token(extract_auth_token(request))
            
            if not user_id:
                
                abort(403)
                
            trans = []
 
       #query transaction requests from the database for the recipient id
            transaction_requests = TransactionRequests.query.filter_by(recipient_id=user_id).all()
            
            
            for t in transaction_requests:
                sender = User.query.filter_by(id=TransactionRequests.sender_id).first()
                sender_name = sender.user_name
                trans.append({
                    'trans_req_id':t.id,
                    'sender_id':t.sender_id,
                    'sender_name': sender_name,
                    'recipient_id':t.recipient_id,
                    'usd_amount':t.usd_amount,
                    'lbp_amount':t.lbp_amount,
                    'usd_to_lbp':t.usd_to_lbp,
                    'status':t.status,
                    'added_date':t.added_date
                })
                
            return jsonify( trans), 200
                

        
    else:
        
         abort(401, 'Authentication token is missing or invalid.')





# Manage transaction requests
@app.route('/transaction_request/<int:request_id>', methods=['POST'])
def update_transaction_request_status(request_id):

    if extract_auth_token(request):

        if decode_token(extract_auth_token(request)):

            user_id = decode_token(extract_auth_token(request))

            if not user_id:

                abort(403)

            transaction_request = TransactionRequests.query.get(request_id)

            if not transaction_request:

                return jsonify({'error': 'Transaction request not found'}), 404

            if transaction_request.recipient_id != user_id:

                return jsonify({'error': 'You are not authorized to update this transaction request'}), 403

            if transaction_request.status != 'pending':

                return jsonify({'error': 'Transaction request is already {}'.format(transaction_request.status)}), 400

            status = request.json['status']
            if status not in ['accepted', 'rejected']:
                return jsonify({'error': 'Invalid status value. Only "accepted" and "rejected" are allowed.'}), 400


            if status == 'accepted':
                # Create new transaction objects
                sender_transaction = Transaction(
                    usd_amount=transaction_request.usd_amount,
                    lbp_amount=transaction_request.lbp_amount,
                    usd_to_lbp=transaction_request.usd_to_lbp,
                    user_id=transaction_request.sender_id
                )
                recipient_transaction = Transaction(
                    usd_amount=transaction_request.usd_amount,
                    lbp_amount=transaction_request.lbp_amount,
                    usd_to_lbp= not transaction_request.usd_to_lbp,
                    user_id=transaction_request.recipient_id
                )

                # Add transaction objects to database in case of success
                db.session.add(sender_transaction)
                db.session.add(recipient_transaction)

            transaction_request.status = status
            db.session.commit()

            return jsonify({'message': 'Transaction request updated successfully'}), 200
    else:
        abort(401, 'Authentication token is missing or invalid.')