DB_CONFIG = 'mysql+pymysql://root:rootroot@127.0.0.1:3306/exchange'

# DB_CONFIG = 'mysql+pymysql://xcbcsys1fk4il634:vph8kpg3usfjvt5r@w3epjhex7h2ccjxx.cbetxkdyhwsb.us-east-1.rds.amazonaws.com:3306/lijgv6mtob7tkvty'





# Server name
# exchange430lab
# Engine
# MySQL - Flexible Server
# Database name
# exchange
# Region
# West Europe
# Username
# qqbdciivnm
# Password
# H5R85545087XPL86$
