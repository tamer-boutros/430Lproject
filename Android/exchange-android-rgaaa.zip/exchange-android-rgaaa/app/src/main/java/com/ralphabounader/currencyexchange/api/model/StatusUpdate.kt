package com.ralphabounader.currencyexchange.api.model

import com.google.gson.annotations.SerializedName

class StatusUpdate {

    @SerializedName("status")
    var status: String? = null

}