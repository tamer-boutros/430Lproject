package com.ralphabounader.currencyexchange.api.model

data class TransactionRequestStatusUpdate(val status: String)
