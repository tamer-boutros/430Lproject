package com.ralphabounader.currencyexchange

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.ralphabounader.currencyexchange.api.ExchangeService
import com.ralphabounader.currencyexchange.api.model.ExchangeRates
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response




class ExchangeFragment : Fragment() {


    private var buyUsdTextView: TextView? = null
    private var sellUsdTextView: TextView? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fetchRates()
    }





    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        var view: View = inflater.inflate(R.layout.fragment_exchange, container, false)
        buyUsdTextView = view.findViewById(R.id.txtBuyUsdRate)
        sellUsdTextView = view.findViewById(R.id.txtSellUsdRate)
        super.onCreate(savedInstanceState)
        fetchRates()

        val btnStats = view.findViewById<Button>(R.id.btnStats)
        btnStats.setOnClickListener {
            val intent = Intent(requireContext(), StatsActivity::class.java)
            startActivity(intent)
        }



        val friendsButton: Button = view.findViewById(R.id.friendsButton)
        friendsButton.setOnClickListener {
            val intent = Intent(requireActivity(), FriendsActivity::class.java)
            startActivity(intent)
        }

        val tradeButton: Button = view.findViewById(R.id.tradeButton)
        tradeButton.setOnClickListener {
            val intent = Intent(requireActivity(), TransactionsActivity::class.java)
            startActivity(intent)
        }

        val btnStats2 = view.findViewById<Button>(R.id.btnStats2)
        btnStats2.setOnClickListener {
            val intent = Intent(requireContext(), StatisticsActivity::class.java)
            startActivity(intent)
        }
        return view
    }

    private fun fetchRates(){
        ExchangeService.exchangeApi().getExchangeRates().enqueue(object :
            Callback<ExchangeRates> {
            override fun onResponse(call: Call<ExchangeRates>, response:
            Response<ExchangeRates>
            ) {
                val responseBody: ExchangeRates? = response.body();
                val buyUsdRate = responseBody?.usdToLbp.toString()
                val sellUsdRate = responseBody?.lbpToUsd.toString()

                buyUsdTextView?.text = buyUsdRate
                sellUsdTextView?.text = sellUsdRate }
            override fun onFailure(call: Call<ExchangeRates>, t: Throwable) {
                return;
                TODO("Not yet implemented")
            }
        })
    }


}