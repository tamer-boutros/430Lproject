package com.ralphabounader.currencyexchange

import BuyPredictionsFragment
import SellPredictionsFragment
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.viewpager.widget.ViewPager
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.ralphabounader.currencyexchange.api.ExchangeService
import com.ralphabounader.currencyexchange.api.model.ExchangeRates
import com.ralphabounader.currencyexchange.api.model.PredictionResponse
import com.ralphabounader.currencyexchange.api.model.Times
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalTime
import java.util.*
import com.github.mikephil.charting.data.Entry
import com.ralphabounader.currencyexchange.api.model.FuturePrediction
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator



class StatsActivity : AppCompatActivity() {

    private lateinit var sellTimeLabel: TextView
    private lateinit var buyTimeLabel: TextView
    private lateinit var sellTimeClock: StaticAnalogClock
    private lateinit var buyTimeClock: StaticAnalogClock
    private lateinit var viewPager: ViewPager2
    private lateinit var sellChart: LineChart
    private lateinit var buyChart: LineChart

    val sellPredictionsFragment = SellPredictionsFragment()
    val buyPredictionsFragment = BuyPredictionsFragment()
    val fragments = listOf(sellPredictionsFragment, buyPredictionsFragment)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        sellTimeLabel = findViewById(R.id.sell_time_label)
        buyTimeLabel = findViewById(R.id.buy_time_label)
        sellTimeClock = findViewById(R.id.sell_time_clock)
        buyTimeClock = findViewById(R.id.buy_time_clock)







        viewPager = findViewById(R.id.view_pager)
        val tabLayout: TabLayout = findViewById(R.id.tab_layout)

        val sellPredictionsFragment = SellPredictionsFragment()
        val buyPredictionsFragment = BuyPredictionsFragment()
        val fragments = listOf(sellPredictionsFragment, buyPredictionsFragment)

        val pagerAdapter = PredictionsPageAdapter(supportFragmentManager, lifecycle, fragments)
        viewPager.adapter = pagerAdapter

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = if (position == 0) "Sell Predictions" else "Buy Predictions"
        }.attach()


        fetchTimes()

        val fetchPredictionsButton: Button = findViewById(R.id.fetch_predictions_button)
        fetchPredictionsButton.setOnClickListener {
            val numDaysInput: EditText = findViewById(R.id.num_days_input)
            val numDays = numDaysInput.text.toString().toIntOrNull()
            if (numDays != null) {
                fetchPredictions(numDays)
            } else {
                Toast.makeText(this, "Please enter a valid number of days", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun fetchTimes(){
        ExchangeService.exchangeApi().getBestTime().enqueue(object :
            Callback<Times> {
            override fun onResponse(call: Call<Times>, response:
            Response<Times>
            ) {
                val responseBody: Times? = response.body();
                val sellTime = responseBody?.bestSellTime.toString()
                val buyTime = responseBody?.bestBuyTime.toString()

                val sellTimeLabel = findViewById<TextView>(R.id.sell_time_label)
                val buyTimeLabel = findViewById<TextView>(R.id.buy_time_label)
                Log.e("fetched", sellTime)

                val sellTimeParts = sellTime.split(":")
                val buyTimeParts = buyTime.split(":")

                val sellTimeHour = sellTimeParts[0].toInt()
                val sellTimeMinute = sellTimeParts[1].toInt()
                val buyTimeHour = buyTimeParts[0].toInt()
                val buyTimeMinute = buyTimeParts[1].toInt()

                sellTimeLabel.text = "Best Time to Sell: $sellTime"
                buyTimeLabel.text = "Best Time to Buy: $buyTime"

                sellTimeClock.setTime(sellTimeHour, sellTimeMinute)
                buyTimeClock.setTime(buyTimeHour, buyTimeMinute)

                sellTimeLabel.text = "Best Time to Sell: $sellTime"
                buyTimeLabel.text = "Best Time to Buy: $buyTime"

            }

            override fun onFailure(call: Call<Times>, t: Throwable) {
                Log.e("fetchTimes", "Network call failed: ${t.message}")
            }
        })
    }
    private fun parseTime(timeString: String): Date? {
        val parts = timeString.split(":")
        if (parts.size != 3) {
            return null
        }

        return try {
            val hours = parts[0].toInt()
            val minutes = parts[1].toInt()
            val seconds = parts[2].toInt()

            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR_OF_DAY, hours)
            calendar.set(Calendar.MINUTE, minutes)
            calendar.set(Calendar.SECOND, seconds)

            calendar.time
        } catch (e: NumberFormatException) {
            null
        }
    }


    fun setupChart(chart: LineChart) {
        chart.description.isEnabled = false
        chart.setTouchEnabled(true)
        chart.isDragEnabled = true
        chart.setScaleEnabled(true)
        chart.setPinchZoom(true)
    }

    private fun populateChart(sellChart: LineChart, buyChart: LineChart, futureSell: List<FuturePrediction>, futureBuy: List<FuturePrediction>) {
        val sellEntries = mutableListOf<Entry>()
        val buyEntries = mutableListOf<Entry>()

        futureSell.forEachIndexed { index, prediction ->
            prediction.value?.let { value ->
                sellEntries.add(Entry(index.toFloat(), value.toFloat()))
            }
        }

        futureBuy.forEachIndexed { index, prediction ->
            prediction.value?.let { value ->
                buyEntries.add(Entry(index.toFloat(), value.toFloat()))
            }
        }

        val sellDataSet = LineDataSet(sellEntries, "Sell Predictions")
        val buyDataSet = LineDataSet(buyEntries, "Buy Predictions")

        sellChart.data = LineData(sellDataSet)
        buyChart.data = LineData(buyDataSet)

        Log.d("populateChart", "sellEntries: $sellEntries")
        Log.d("populateChart", "buyEntries: $buyEntries")

        sellDataSet.color = Color.parseColor("#4db5ff")
        sellDataSet.lineWidth = 2f
        buyDataSet.color = Color.parseColor("#4db5ff")
        buyDataSet.lineWidth = 2f

        sellChart.invalidate()
        buyChart.invalidate()
    }



    private fun fetchPredictions(days: Int) {
        ExchangeService.exchangeApi().getPredictions(days).enqueue(object : Callback<PredictionResponse> {
            override fun onResponse(call: Call<PredictionResponse>, response: Response<PredictionResponse>) {
                val responseBody = response.body()

                if (response.isSuccessful) {
                    responseBody?.let {
                        sellPredictionsFragment.updatePredictions(it.futureSell ?: emptyList())
                        buyPredictionsFragment.updatePredictions(it.futureBuy ?: emptyList())
                        sellPredictionsFragment.sellChart?.let { sellChart ->
                            buyPredictionsFragment.buyChart?.let { buyChart ->
                                populateChart(sellChart, buyChart, responseBody.futureSell ?: emptyList(), responseBody.futureBuy ?: emptyList())
                            }
                        }
                    }
                }
                else {
                    Log.e("fetchPredictions", "Network call failed: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<PredictionResponse>, t: Throwable) {
                Log.e("fetchPredictions", "Network call failed: ${t.message}")
            }
        })
    }


}








