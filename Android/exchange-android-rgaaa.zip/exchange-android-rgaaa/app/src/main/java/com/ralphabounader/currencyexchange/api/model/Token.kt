package com.ralphabounader.currencyexchange.api.model

import com.google.gson.annotations.SerializedName

class Token {
    @SerializedName("token")
    var token: String? = null
}