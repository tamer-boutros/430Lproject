package com.ralphabounader.currencyexchange

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.appcompat.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ralphabounader.currencyexchange.api.Authentication
import com.ralphabounader.currencyexchange.api.ExchangeService
import com.ralphabounader.currencyexchange.api.model.Friend
import com.ralphabounader.currencyexchange.api.model.FriendRequest
import com.ralphabounader.currencyexchange.api.model.StatusUpdate
import com.ralphabounader.currencyexchange.api.model.User
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FriendsActivity : AppCompatActivity() {

    private lateinit var recyclerViewNonFriendUsers: RecyclerView

    private lateinit var nonFriendUsers: List<User>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_friends)

        fetchFriends()
        fetchNonFriendUsers()
        fetchFriendRequests()

    }

    private fun fetchNonFriendUsers() {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"
            ExchangeService.exchangeApi().getNonFriendUsers(authHeader).enqueue(object : Callback<List<User>> {
                override fun onResponse(call: Call<List<User>>, response: Response<List<User>>) {
                    val responseBody = response.body()

                    if (responseBody != null) {
                        nonFriendUsers = responseBody
                        setupAutoCompleteTextView()

                    }
                }

                override fun onFailure(call: Call<List<User>>, t: Throwable) {

                }
            })
        } else {
        }
    }

    private fun setupSearchView() {
        val searchView = findViewById<SearchView>(R.id.search_view)

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    val filteredUsers = filterUsers(newText)
                    displayNonFriendUsers(filteredUsers)
                }
                return true
            }
        })
    }

    private fun filterUsers(query: String): List<User> {
        return nonFriendUsers.filter { user ->
            user.username?.startsWith(query, ignoreCase = true) == true
        }
    }

    private fun setupAutoCompleteTextView() {
        val autoCompleteTextView = findViewById<AutoCompleteTextView>(R.id.autoCompleteTextView)

        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, ArrayList<String>())
        autoCompleteTextView.setAdapter(adapter)

        autoCompleteTextView.setOnItemClickListener { parent, view, position, id ->
            val selectedItem = parent.getItemAtPosition(position) as String
            AlertDialog.Builder(this)
                .setTitle("Add Friend")
                .setMessage("Add $selectedItem as a friend?")
                .setPositiveButton("Yes") { dialog, _ ->
                    dialog.dismiss()
                    sendFriendRequest(selectedItem)
                }
                .setNegativeButton("No") { dialog, _ ->
                    dialog.dismiss()
                }
                .show()
        }

        autoCompleteTextView.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val query = s.toString()
                if (query.isNotEmpty()) {
                    val filteredUsers = nonFriendUsers.filter { user ->
                        user.username?.startsWith(query, ignoreCase = true) == true
                    }
                    adapter.clear()
                    adapter.addAll(filteredUsers.map { it.username })
                    adapter.notifyDataSetChanged()
                } else {
                    adapter.clear()
                }
            }

            override fun afterTextChanged(s: Editable) {
            }
        })
    }

    private fun sendFriendRequest(friendName: String) {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"
            val body = hashMapOf("friend_name" to friendName)

            ExchangeService.exchangeApi().addFriend(authHeader, body).enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@FriendsActivity, "Friend request sent", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@FriendsActivity, "Failed to send friend request", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(this@FriendsActivity, "Error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            })
        } else {
        }
    }

    private fun fetchFriendRequests() {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"

            ExchangeService.exchangeApi().getFriendRequests(authHeader).enqueue(object : Callback<List<FriendRequest>> {
                override fun onResponse(call: Call<List<FriendRequest>>, response: Response<List<FriendRequest>>) {
                    val responseBody = response.body()

                    if (responseBody != null) {
                        displayFriendRequests(responseBody)
                    }
                }

                override fun onFailure(call: Call<List<FriendRequest>>, t: Throwable) {
                }
            })
        } else {
        }
    }







    private fun displayNonFriendUsers(nonFriendUsers: List<User>?) {
        this.nonFriendUsers = nonFriendUsers ?: emptyList()
        setupAutoCompleteTextView()
    }

    private fun displayFriendRequests(friendRequests: List<FriendRequest>) {
        val incomingFriendRequests = friendRequests.filter { it.request_type == "incoming" }
        val recyclerView = findViewById<RecyclerView>(R.id.incomingFriendRequestsRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = FriendRequestAdapter(incomingFriendRequests, ::acceptFriendRequest, ::rejectFriendRequest)
    }


    private fun acceptFriendRequest(friendRequest: FriendRequest) {
        updateFriendRequestStatus(friendRequest, "accepted")
    }

    private fun rejectFriendRequest(friendRequest: FriendRequest) {
        updateFriendRequestStatus(friendRequest, "rejected")
    }


    private fun updateFriendRequestStatus(friendRequest: FriendRequest, status: String) {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"
            val senderName = friendRequest.user_name
            if (senderName != null) {
                ExchangeService.exchangeApi().updateFriendRequestStatus(authHeader, senderName, StatusUpdate().apply { this.status = status })
                    .enqueue(object : Callback<ResponseBody> {
                        override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                            if (response.isSuccessful) {
                                Toast.makeText(this@FriendsActivity, "Friend request $status successfully", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@FriendsActivity, "Failed to update friend request status", Toast.LENGTH_SHORT).show()
                            }
                        }

                        override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                            Toast.makeText(this@FriendsActivity, "Error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
                        }
                    })
            }
        } else {
        }
    }

    private fun fetchFriends() {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"
            ExchangeService.exchangeApi().getFriends(authHeader)
                .enqueue(object : Callback<List<Friend>> {
                    override fun onResponse(call: Call<List<Friend>>, response: Response<List<Friend>>) {
                        if (response.isSuccessful) {
                            val friends = response.body()
                            if (friends != null) {
                                displayFriends(friends)
                            }
                        } else {
                            Toast.makeText(this@FriendsActivity, "Failed to fetch friends list", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<List<Friend>>, t: Throwable) {
                        Toast.makeText(this@FriendsActivity, "Error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
                    }
                })
        } else {
        }
    }

    private fun displayFriends(friends: List<Friend>) {
        val adapter = FriendsAdapter(friends, object : FriendsAdapter.OnFriendClickListener {
            override fun onRemoveFriendClicked(friend: Friend) {
                removeFriend(friend)
            }
        })

        val recyclerView = findViewById<RecyclerView>(R.id.friendsListRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this) // Add this line
        recyclerView.adapter = adapter
    }


    private fun removeFriend(friend: Friend) {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"
            val friendId = friend.friend_id
            if (friendId != null) {
                ExchangeService.exchangeApi().removeFriend(authHeader, friendId)
                    .enqueue(object : Callback<ResponseBody> {
                        override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                            if (response.isSuccessful) {
                                Toast.makeText(this@FriendsActivity, "Friend removed successfully", Toast.LENGTH_SHORT).show()
                                fetchFriends()
                            } else {
                                Toast.makeText(this@FriendsActivity, "Failed to remove friend", Toast.LENGTH_SHORT).show()
                            }
                        }

                        override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                            Toast.makeText(this@FriendsActivity, "Error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
                        }
                    })
            }
        } else {
        }
    }











}
