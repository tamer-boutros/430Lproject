package com.ralphabounader.currencyexchange




import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.ralphabounader.currencyexchange.R
import com.ralphabounader.currencyexchange.api.ExchangeService
import com.ralphabounader.currencyexchange.api.model.Statistics
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class StatisticsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_statistics)

        fetchStatistics()
    }

    private fun fetchStatistics() {
        ExchangeService.exchangeApi().getStatistics().enqueue(object : Callback<Statistics> {
            override fun onResponse(call: Call<Statistics>, response: Response<Statistics>) {
                val responseBody = response.body()

                if (responseBody != null) {
                    displayStatistics(responseBody)
                }
            }

            override fun onFailure(call: Call<Statistics>, t: Throwable) {
            }
        })
    }

    private fun displayStatistics(statistics: Statistics) {
        val totalTransactions = findViewById<TextView>(R.id.total_transactions)
        val sellTransactions = findViewById<TextView>(R.id.sell_transactions)
        val buyTransactions = findViewById<TextView>(R.id.buy_transactions)
        val avgSellUSD = findViewById<TextView>(R.id.avg_sell_usd)
        val avgBuyUSD = findViewById<TextView>(R.id.avg_buy_usd)

        totalTransactions.text = "Total Transactions: ${statistics.total.totalNumberOfTransactions}"
        sellTransactions.text = "Sell Transactions: ${statistics.sellUSD.totalNumberOfTransactions}"
        buyTransactions.text = "Buy Transactions: ${statistics.buyUSD.totalNumberOfTransactions}"
        avgSellUSD.text = "Average Sell USD: ${statistics.sellUSD.average}"
        avgBuyUSD.text = "Average Buy USD: ${statistics.buyUSD.average}"

        val medianSellUSD = findViewById<TextView>(R.id.median_sell_usd)
        medianSellUSD.text = "Median Sell USD: ${statistics.sellUSD.median}"

        val medianBuyUSD = findViewById<TextView>(R.id.median_buy_usd)
        medianBuyUSD.text = "Median Buy USD: ${statistics.buyUSD.median}"

        val stddevSellUSD = findViewById<TextView>(R.id.stddev_sell_usd)
        stddevSellUSD.text = "Standard Deviation Sell USD: ${statistics.sellUSD.stddev}"

        val stddevBuyUSD = findViewById<TextView>(R.id.stddev_buy_usd)
        stddevBuyUSD.text = "Standard Deviation Buy USD: ${statistics.buyUSD.stddev}"

        val volatilitySellUSD = findViewById<TextView>(R.id.volatility_sell_usd)
        volatilitySellUSD.text = "Volatility Sell USD: ${statistics.sellUSD.volatility}"

        val volatilityBuyUSD = findViewById<TextView>(R.id.volatility_buy_usd)
        volatilityBuyUSD.text = "Volatility Buy USD: ${statistics.buyUSD.volatility}"

        val totalUSDVolume = findViewById<TextView>(R.id.total_usd_volume)
        totalUSDVolume.text = "Total USD Volume: ${statistics.total.totalUSDVolume}"

        val totalLBPVolume = findViewById<TextView>(R.id.total_lbp_volume)
        totalLBPVolume.text = "Total LBP Volume: ${statistics.total.totalLBPVolume}"

        val buyTransactionsPercentage = findViewById<TextView>(R.id.buy_transactions_percentage)
        buyTransactionsPercentage.text = "Buy Transactions Percentage: ${statistics.total.buyTransactionsPercentage}"

        val sellTransactionsPercentage = findViewById<TextView>(R.id.sell_transactions_percentage)
        sellTransactionsPercentage.text = "Sell Transactions Percentage: ${statistics.total.sellTransactionsPercentage}"
    }

}

