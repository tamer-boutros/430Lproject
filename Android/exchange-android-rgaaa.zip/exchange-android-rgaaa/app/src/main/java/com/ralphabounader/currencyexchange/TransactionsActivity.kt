package com.ralphabounader.currencyexchange

import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ralphabounader.currencyexchange.api.Authentication
import com.ralphabounader.currencyexchange.api.ExchangeService
import com.ralphabounader.currencyexchange.api.model.Friend
import com.ralphabounader.currencyexchange.api.model.TransactionRequest
import com.ralphabounader.currencyexchange.api.model.TransactionRequestItem
import com.ralphabounader.currencyexchange.api.model.TransactionRequestStatusUpdate
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TransactionsActivity : AppCompatActivity() {

    private lateinit var friendsSpinner: Spinner
    private lateinit var transactionRequestAdapter: TransactionRequestAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_transactions)

        friendsSpinner = findViewById(R.id.friendsSpinner)
        fetchUsers()

        val lbpAmountEditText = findViewById<EditText>(R.id.lbpAmountEditText)
        val usdAmountEditText = findViewById<EditText>(R.id.usdAmountEditText)
        val transactionTypeRadioGroup = findViewById<RadioGroup>(R.id.transactionTypeRadioGroup)

        val createTransactionButton: Button = findViewById(R.id.createTransactionButton)

        createTransactionButton.setOnClickListener {
            val receiverUsername = friendsSpinner.selectedItem.toString()
            val lbpAmountText = lbpAmountEditText.text.toString()
            val usdAmountText = usdAmountEditText.text.toString()
            val lbpAmount = lbpAmountText.toDoubleOrNull()
            val usdAmount = usdAmountText.toDoubleOrNull()
            val usdToLbp = transactionTypeRadioGroup.checkedRadioButtonId == R.id.sellUsdRadioButton

            if (lbpAmount != null && usdAmount != null) {
                sendTransaction(receiverUsername, usdAmount, lbpAmount, usdToLbp)
            } else {
                Toast.makeText(this, "Invalid amount(s)", Toast.LENGTH_SHORT).show()
            }
        }

        val transactionRequestsRecyclerView: RecyclerView =
            findViewById(R.id.transactionRequestsRecyclerView)
        transactionRequestAdapter = TransactionRequestAdapter(
            emptyList(),
            ::acceptTransactionRequest,
            ::rejectTransactionRequest
        )
        transactionRequestsRecyclerView.adapter = transactionRequestAdapter
        transactionRequestsRecyclerView.layoutManager = LinearLayoutManager(this)

        fetchTransactionRequests()
    }

    private fun setupSpinner(friends: List<Friend>) {
        val adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_item, friends.map { it.user_name })
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        friendsSpinner.adapter = adapter
    }

    private fun fetchUsers() {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"
            ExchangeService.exchangeApi().getFriends(authHeader)
                .enqueue(object : Callback<List<Friend>> {
                    override fun onResponse(
                        call: Call<List<Friend>>,
                        response: Response<List<Friend>>
                    ) {
                        val responseBody = response.body()
                        if (responseBody != null) {
                            setupSpinner(responseBody)
                        }
                    }

                    override fun onFailure(call: Call<List<Friend>>, t: Throwable) {
                        // Handle failure
                    }
                })
        } else {
            // Handle the case when the token is not available
        }
    }

    private fun sendTransaction(receiverUsername: String, usdAmount: Double, lbpAmount: Double, usdToLbp: Boolean) {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"

            val requestBody = TransactionRequestItem(
                recipient_username = receiverUsername,
                usd_amount = usdAmount.toFloat(),
                lbp_amount = lbpAmount.toFloat(),
                usd_to_lbp = usdToLbp,
                status = "pending"
            )

            ExchangeService.exchangeApi().createTransactionRequest(authHeader, requestBody).enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@TransactionsActivity, "Transaction sent", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@TransactionsActivity, "Failed to send transaction", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(this@TransactionsActivity, "Error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
                }
            })
        } else {
            // Handle the case when the token is not available
        }
    }

    private fun fetchTransactionRequests() {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"
            ExchangeService.exchangeApi().getTransactionRequests(authHeader).enqueue(object : Callback<List<TransactionRequest>> {
                override fun onResponse(call: Call<List<TransactionRequest>>, response: Response<List<TransactionRequest>>) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        transactionRequestAdapter.transactionRequests = responseBody
                        transactionRequestAdapter.notifyDataSetChanged()
                        Log.d("TransactionRequests", "Fetched transaction requests: $responseBody")
                    }
                }

                override fun onFailure(call: Call<List<TransactionRequest>>, t: Throwable) {
                    // Handle failure
                }
            })
        } else {
            // Handle the case when the token is not available
        }
    }

    private fun acceptTransactionRequest(transactionRequest: TransactionRequest) {
        updateTransactionRequestStatus(transactionRequest, "accepted")
    }

    private fun rejectTransactionRequest(transactionRequest: TransactionRequest) {
        updateTransactionRequestStatus(transactionRequest, "rejected")
    }


//    private fun updateTransactionRequestStatus(transactionRequest: TransactionRequest, status: String) {
//        val token = Authentication.getToken()
//        if (token != null) {
//            val authHeader = "Bearer $token"
//            val statusUpdate = hashMapOf("status" to status)
//
//            ExchangeService.exchangeApi().updateTransactionRequestStatus(authHeader, transactionRequest.trans_req_id ?: -1, statusUpdate).enqueue(object : Callback<ResponseBody> {
//                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
//                    if (response.isSuccessful) {
//                        Log.d("TransactionRequest", "Status updated: $status")
//                        fetchTransactionRequests()
//                    } else {
//                        Log.e("TransactionRequest", "Failed to update status: ${response.message()}")
//                    }
//                }
//
//                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
//                    Log.e("TransactionRequest", "Error updating status: ${t.message}")
//                }
//            })
//        } else {
//        }
//    }

    private fun updateTransactionRequestStatus(transactionRequest: TransactionRequest, status: String) {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"
            val statusUpdate = TransactionRequestStatusUpdate(status)

            ExchangeService.exchangeApi().updateTransactionRequestStatus(authHeader, transactionRequest.trans_req_id
                ?: -1, statusUpdate).enqueue(object : Callback<ResponseBody> {
                override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                    if (response.isSuccessful) {
                        Log.d("TransactionRequest", "Status updated: $status")
                        fetchTransactionRequests()
                    } else {
                        Log.e("TransactionRequest", "Failed to update status: ${response.message()}")
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Log.e("TransactionRequest", "Error updating status: ${t.message}")
                }
            })
        } else {
        }
    }


}












