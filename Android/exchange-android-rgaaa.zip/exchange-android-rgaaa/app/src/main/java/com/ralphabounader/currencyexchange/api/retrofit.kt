package com.ralphabounader.currencyexchange.api

import com.ralphabounader.currencyexchange.api.model.*
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

object ExchangeService {
//    private const val API_URL: String = "http://10.0.2.2:5000"
    private const val API_URL: String = "https://project430l.herokuapp.com"


    fun exchangeApi(): Exchange {
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl(API_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        return retrofit.create(Exchange::class.java);
    }

    interface Exchange {
        @GET("/exchangerate")
        fun getExchangeRates(): Call<ExchangeRates>

        @POST("/transaction")
        fun addTransaction(@Body transaction: Transaction, @Header("Authorization") authorization: String?): Call<Any>

        @GET("/transaction")
        fun getTransactions(@Header("Authorization") authorization: String): Call<List<Transaction>>

        @POST("/newuser")
        fun addUser(@Body user : User): Call<User>

        @POST("/authenticate")
        fun authenticate(@Body user: User): Call<Token>

        @GET("best_time")
        fun getBestTime(): Call<Times>

        @GET("predict/{days}")
        fun getPredictions(@Path("days") days: Int): Call<PredictionResponse>

        @GET("stats")
        fun getStatistics(): Call<Statistics>

        @GET("users/nonfriends")
        fun getNonFriendUsers(@Header("Authorization") authHeader: String): Call<List<User>>

        @GET("users/friends")
        fun getFriends(@Header("Authorization") authHeader: String): Call<List<Friend>>

        @DELETE("users/remove_friend/{friend_id}")
        fun removeFriend(@Header("Authorization") authHeader: String, @Path("friend_id") friendId: Int): Call<ResponseBody>

        @POST("/users/add_friend")
        fun addFriend(@Header("Authorization") authHeader: String, @Body body: HashMap<String, String>): Call<ResponseBody>


        @GET("/users/friend_requests")
        fun getFriendRequests(@Header("Authorization") authHeader: String): Call<List<FriendRequest>>


        @PUT("users/request_action/{sender_name}")
        fun updateFriendRequestStatus(
            @Header("Authorization") authHeader: String,
            @Path("sender_name") senderName: String,
            @Body statusUpdate: StatusUpdate
        ): Call<ResponseBody>

        @POST("transaction_request")
        fun createTransactionRequest(
            @Header("Authorization") authHeader: String,
            @Body requestBody: TransactionRequestItem
        ): Call<ResponseBody>


        @GET("get_transaction_requests")
        fun getTransactionRequests(@Header("Authorization") authHeader: String): Call<List<TransactionRequest>>

        @POST("/transaction_request/{request_id}")
        fun updateTransactionRequestStatus(
            @Header("Authorization") authHeader: String,
            @Path("request_id") requestId: Int,
            @Body statusUpdate: TransactionRequestStatusUpdate
        ): Call<ResponseBody>







    }

    }

