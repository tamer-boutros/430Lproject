package com.ralphabounader.currencyexchange
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ralphabounader.currencyexchange.R
import com.ralphabounader.currencyexchange.api.model.FriendRequest

class FriendRequestAdapter(
    private val friendRequests: List<FriendRequest>,
    private val acceptClickListener: (FriendRequest) -> Unit,
    private val rejectClickListener: (FriendRequest) -> Unit
) : RecyclerView.Adapter<FriendRequestAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val friendRequestName: TextView = view.findViewById(R.id.friendRequestName)
        val acceptButton: Button = view.findViewById(R.id.acceptButton)
        val rejectButton: Button = view.findViewById(R.id.rejectButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.friend_request_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val friendRequest = friendRequests[position]
        holder.friendRequestName.text = friendRequest.user_name

        holder.acceptButton.setOnClickListener {
            acceptClickListener(friendRequest)
        }
        holder.rejectButton.setOnClickListener {
            rejectClickListener(friendRequest)
        }
    }

    override fun getItemCount() = friendRequests.size
}
