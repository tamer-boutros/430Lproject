import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.ralphabounader.currencyexchange.R
import com.ralphabounader.currencyexchange.StatsActivity
import com.ralphabounader.currencyexchange.api.model.FuturePrediction

class SellPredictionsFragment : Fragment() {

    var sellChart: LineChart? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_sell_predictions, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sellChart = view.findViewById(R.id.sell_chart)
//        sellChart?.let { setupChart(it) }


    }

    private fun setupChart(chart: LineChart) {
        chart.description.isEnabled = false
        chart.setTouchEnabled(true)
        chart.isDragEnabled = true
        chart.setScaleEnabled(true)
        chart.setPinchZoom(true)
    }

    fun updatePredictions(futureSell: List<FuturePrediction>) {
        val sellEntries = mutableListOf<Entry>()

        futureSell.forEachIndexed { index, prediction ->
            prediction.value?.let { value ->
                sellEntries.add(Entry(index.toFloat(), value.toFloat()))
            }
        }

        val sellDataSet = LineDataSet(sellEntries, "Sell Predictions")
        sellDataSet.color = Color.parseColor("#4db5ff")
        sellDataSet.lineWidth = 2f

        sellChart?.let {
            it.data = LineData(sellDataSet)
            it.invalidate()
        }
    }

}
