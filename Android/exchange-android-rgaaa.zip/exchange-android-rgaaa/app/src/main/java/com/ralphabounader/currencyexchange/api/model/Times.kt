package com.ralphabounader.currencyexchange.api.model
import com.google.gson.annotations.SerializedName
import java.sql.Date

class Times {

    @SerializedName("best_sell_time")
    var bestSellTime: String? = null
    @SerializedName("best_buy_time")
    var bestBuyTime: String? = null
}