package com.ralphabounader.currencyexchange

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputLayout
import com.ralphabounader.currencyexchange.api.Authentication
import com.ralphabounader.currencyexchange.api.ExchangeService
import com.ralphabounader.currencyexchange.api.model.Token
import com.ralphabounader.currencyexchange.api.model.User
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

//    fun View.announceForAccessibilityCompat(text: CharSequence) {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            announceForAccessibility(text)
//        } else {
//            val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
//            if (!accessibilityManager.isEnabled) {
//                return
//            }
//            val event = AccessibilityEvent.obtain(AccessibilityEvent.TYPE_ANNOUNCEMENT)
//            event.text.add(text)
//            accessibilityManager.sendAccessibilityEvent(event)
//        }
//    }
//
//
//    override fun onResume() {
//        super.onResume()
//        Log.d("MyApp", "This is a debug message")
//        val announcement = "Hello Ralph. I hope this reader is to your liking."
//        findViewById<View>(android.R.id.content).announceForAccessibilityCompat(announcement)
//    }

    private var usernameEditText: TextInputLayout? = null
    private var passwordEditText: TextInputLayout? = null
    private var submitButton: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        usernameEditText = findViewById(R.id.txtInptUsername)
        passwordEditText = findViewById(R.id.txtInptPassword)
        submitButton = findViewById(R.id.btnSubmit)
        submitButton?.setOnClickListener { view ->
            loginUser()
        }
    }
    private fun loginUser() {
        val user = User()
        user.username = usernameEditText?.editText?.text.toString()
        user.password = passwordEditText?.editText?.text.toString()
        ExchangeService.exchangeApi().authenticate(user).enqueue(object :
            Callback<Token> {
            override fun onFailure(call: Call<Token>, t: Throwable) {
                Snackbar.make(
                    submitButton as View,
                    "Could not login!",
                    Snackbar.LENGTH_LONG
                )
                    .show()
            }
            override fun onResponse(call: Call<Token>, response:
            Response<Token>
            ) {

                ExchangeService.exchangeApi().authenticate(user).enqueue(object :
                    Callback<Token> {
                    override fun onFailure(call: Call<Token>, t:
                    Throwable) {
                        return
                    }
                    override fun onResponse(call: Call<Token>, response:
                    Response<Token>
                    ) {
                        Snackbar.make(
                            submitButton as View,
                            "Account Created.",
                            Snackbar.LENGTH_LONG
                        )
                            .show()
                        response.body()?.token?.let {
                            Authentication.saveToken(it) }
                        onCompleted()
                    }
                })
            }
        })
    }
    private fun onCompleted() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        startActivity(intent)
    }
}