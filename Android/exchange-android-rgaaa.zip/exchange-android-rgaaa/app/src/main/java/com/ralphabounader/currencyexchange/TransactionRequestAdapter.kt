package com.ralphabounader.currencyexchange

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ralphabounader.currencyexchange.api.model.TransactionRequest
import java.util.*

class TransactionRequestAdapter(
    var transactionRequests: List<TransactionRequest>,
    private val acceptClickListener: (TransactionRequest) -> Unit,
    private val rejectClickListener: (TransactionRequest) -> Unit
) : RecyclerView.Adapter<TransactionRequestAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val transactionRequestStatus: TextView = itemView.findViewById(R.id.transactionRequestStatus)
        val transactionRequestName: TextView = view.findViewById(R.id.transactionRequestName)
        val lbpAmount: TextView = view.findViewById(R.id.transactionRequestLbpAmount)
        val usdAmount: TextView = view.findViewById(R.id.transactionRequestUsdAmount)
        val transactionRequestType: TextView = view.findViewById(R.id.transactionRequestType)
        val acceptButton: Button = view.findViewById(R.id.acceptTransactionButton)
        val rejectButton: Button = view.findViewById(R.id.rejectTransactionButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.transaction_request_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val transactionRequest = transactionRequests[position]
        holder.transactionRequestName.text = "Transaction from ${transactionRequest.sender_name}"
        holder.lbpAmount.text = "LBP: ${transactionRequest.lbp_amount}"
        holder.usdAmount.text = "USD: ${transactionRequest.usd_amount}"
        holder.transactionRequestType.text = if (transactionRequest.usd_to_lbp) "USD to LBP" else "LBP to USD"

        if (transactionRequest.status == "pending") {
            holder.transactionRequestStatus.visibility = View.GONE
            holder.acceptButton.visibility = View.VISIBLE
            holder.rejectButton.visibility = View.VISIBLE

            holder.acceptButton.setOnClickListener {
                acceptClickListener(transactionRequest)
            }
            holder.rejectButton.setOnClickListener {
                rejectClickListener(transactionRequest)
            }
        } else {
            holder.transactionRequestStatus.visibility = View.VISIBLE
            holder.acceptButton.visibility = View.GONE
            holder.rejectButton.visibility = View.GONE

            holder.transactionRequestStatus.text = transactionRequest.status.capitalize(Locale.ROOT)
        }
    }


    override fun getItemCount() = transactionRequests.size
}
