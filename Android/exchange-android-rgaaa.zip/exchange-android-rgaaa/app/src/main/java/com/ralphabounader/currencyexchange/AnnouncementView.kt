package com.ralphabounader.currencyexchange

import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityManager
import androidx.appcompat.widget.AppCompatTextView
import androidx.core.content.res.use

class AnnouncementView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatTextView(context, attrs, defStyleAttr) {

    private var announcementText: String = ""

    init {
        context.obtainStyledAttributes(attrs, R.styleable.AnnouncementView).use {
            announcementText = it.getString(R.styleable.AnnouncementView_announcementText) ?: ""
        }
    }

    fun announceForAccessibilityCompat(text: CharSequence) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            announceForAccessibility(text)
        } else {
            val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            if (!accessibilityManager.isEnabled) {
                return
            }
            val event = AccessibilityEvent.obtain(AccessibilityEvent.TYPE_ANNOUNCEMENT)
            event.text.add(text)
            accessibilityManager.sendAccessibilityEvent(event)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        announceForAccessibilityCompat(announcementText)
    }
}
