package com.ralphabounader.currencyexchange

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class StaticAnalogClock(context: Context, attrs: AttributeSet) : View(context, attrs) {
    private val paint = Paint()
    private var hour: Int = 0
    private var minute: Int = 0

    fun setTime(hour: Int, minute: Int) {
        this.hour = hour
        this.minute = minute
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val centerX = width / 2f
        val centerY = height / 2f

        paint.color = Color.BLACK
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 10f
        canvas.drawCircle(centerX, centerY, centerX - 10f, paint)

        paint.color = Color.BLUE
        paint.strokeWidth = 20f
        val hourEndPoint = getClockHandEndPoint(centerX, centerY, hour % 12 / 12f, 0.5f)
        canvas.drawLine(centerX, centerY, hourEndPoint.x, hourEndPoint.y, paint)

        paint.color = Color.RED
        paint.strokeWidth = 10f
        val minuteEndPoint = getClockHandEndPoint(centerX, centerY, minute / 60f, 0.7f)
        canvas.drawLine(centerX, centerY, minuteEndPoint.x, minuteEndPoint.y, paint)
    }

    private fun getClockHandEndPoint(
        centerX: Float, centerY: Float, progress: Float, lengthMultiplier: Float
    ): PointF {
        val angle = 2 * PI * progress - PI / 2
        val radius = centerX * lengthMultiplier

        return PointF(
            centerX + (radius * cos(angle)).toFloat(),
            centerY + (radius * sin(angle)).toFloat()
        )
    }
}
