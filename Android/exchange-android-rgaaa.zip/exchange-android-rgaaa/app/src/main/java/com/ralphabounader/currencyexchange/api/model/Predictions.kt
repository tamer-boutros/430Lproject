package com.ralphabounader.currencyexchange.api.model

import com.google.gson.annotations.SerializedName

class FuturePrediction {
    @SerializedName("date")
    var date: String? = null

    @SerializedName("value")
    var value: Float? = null
}

class PredictionResponse {
    @SerializedName("future_sell")
    var futureSell: List<FuturePrediction>? = null

    @SerializedName("future_buy")
    var futureBuy: List<FuturePrediction>? = null
}
