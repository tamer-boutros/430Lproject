package com.ralphabounader.currencyexchange.api.model

import com.google.gson.annotations.SerializedName

class FriendRequest {

    @SerializedName("id")
    var id: Int? = null

    @SerializedName("user_name")
    var user_name: String? = null

    @SerializedName("request_type")
    var request_type: String? = null
}