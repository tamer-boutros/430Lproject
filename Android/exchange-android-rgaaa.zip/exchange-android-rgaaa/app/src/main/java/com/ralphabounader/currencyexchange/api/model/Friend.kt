package com.ralphabounader.currencyexchange.api.model

import com.google.gson.annotations.SerializedName

class Friend {

    @SerializedName("id")
    var id: Int? = null

    @SerializedName("user_name")
    var user_name: String? = null

    @SerializedName("user_id")
    var user_id: Int? = null

    @SerializedName("friend_id")
    var friend_id: Int? = null

    @SerializedName("status")
    var status: String? = null
}
