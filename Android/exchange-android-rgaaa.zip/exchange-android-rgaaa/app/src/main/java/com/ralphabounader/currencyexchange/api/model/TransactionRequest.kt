package com.ralphabounader.currencyexchange.api.model

import com.google.gson.annotations.SerializedName;



class TransactionRequest {
    @SerializedName("trans_req_id")
    var trans_req_id: Int = 0

    @SerializedName("sender_id")
    var sender_id: Int = 0

    @SerializedName("sender_name")
    var sender_name: String = ""

    @SerializedName("recipient_id")
    var recipient_id: Int = 0

    @SerializedName("usd_amount")
    var usd_amount: Float = 0.0f

    @SerializedName("lbp_amount")
    var lbp_amount: Float = 0.0f

    @SerializedName("usd_to_lbp")
    var usd_to_lbp: Boolean = false

    @SerializedName("status")
    var status: String = ""

    @SerializedName("added_date")
    var added_date: String = ""
}

