package com.ralphabounader.currencyexchange.api.model

import com.google.gson.annotations.SerializedName

class TransactionRequestItem(
    @SerializedName("recipient_username")
    var recipient_username: String,

    @SerializedName("usd_amount")
    var usd_amount: Float,

    @SerializedName("lbp_amount")
    var lbp_amount: Float,

    @SerializedName("usd_to_lbp")
    var usd_to_lbp: Boolean,

    @SerializedName("status")
    var status: String
)
