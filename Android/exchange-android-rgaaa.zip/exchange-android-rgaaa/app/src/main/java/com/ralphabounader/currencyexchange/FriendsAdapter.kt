package com.ralphabounader.currencyexchange

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ralphabounader.currencyexchange.R
import com.ralphabounader.currencyexchange.api.model.Friend

class FriendsAdapter(
    private val friends: List<Friend>,
    private val onFriendClickListener: OnFriendClickListener
) : RecyclerView.Adapter<FriendsAdapter.FriendsViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FriendsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.friend_item, parent, false)
        return FriendsViewHolder(view)
    }

    override fun onBindViewHolder(holder: FriendsViewHolder, position: Int) {
        holder.bind(friends[position], onFriendClickListener)
    }

    override fun getItemCount(): Int {
        return friends.size
    }

    class FriendsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val friendNameTextView: TextView = itemView.findViewById(R.id.friendNameTextView)
        private val removeFriendButton: Button = itemView.findViewById(R.id.removeFriendButton)

        fun bind(friend: Friend, onFriendClickListener: OnFriendClickListener) {
            friendNameTextView.text = friend.user_name.toString()
            removeFriendButton.setOnClickListener {
                onFriendClickListener.onRemoveFriendClicked(friend)
            }
        }
    }

    interface OnFriendClickListener {
        fun onRemoveFriendClicked(friend: Friend)
    }
}
