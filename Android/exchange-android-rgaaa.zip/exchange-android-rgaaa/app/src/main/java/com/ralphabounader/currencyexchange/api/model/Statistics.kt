package com.ralphabounader.currencyexchange.api.model

import com.google.gson.annotations.SerializedName

 class Statistics(
    @SerializedName("sellusd")
    val sellUSD: StatItem,
    @SerializedName("buyusd")
    val buyUSD: StatItem,
    @SerializedName("total")
    val total: StatTotal
)

 class StatItem(
    @SerializedName("average")
    val average: Float?,
    @SerializedName("median")
    val median: Float?,
    @SerializedName("stddev")
    val stddev: Float?,
    @SerializedName("volatility")
    val volatility: Float?,
    @SerializedName("total_usd_volume")
    val totalUSDVolume: Float,
    @SerializedName("total_lbp_volume")
    val totalLBPVolume: Float,
    @SerializedName("total_number_of_transactions")
    val totalNumberOfTransactions: Int
)

 class StatTotal(
    @SerializedName("total_usd_volume")
    val totalUSDVolume: Float,
    @SerializedName("total_lbp_volume")
    val totalLBPVolume: Float,
    @SerializedName("% buy transactions")
    val buyTransactionsPercentage: Float,
    @SerializedName("% sell transactions")
    val sellTransactionsPercentage: Float,
    @SerializedName("total_number_of_transactions")
    val totalNumberOfTransactions: Int
)
