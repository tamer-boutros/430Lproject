import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.ralphabounader.currencyexchange.R
import com.ralphabounader.currencyexchange.StatsActivity
import com.ralphabounader.currencyexchange.api.model.FuturePrediction

class BuyPredictionsFragment : Fragment() {

    var buyChart: LineChart? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_buy_predictions, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        buyChart = view.findViewById(R.id.buy_chart)
//        buyChart?.let { setupChart(it) }
    }

    private fun setupChart(chart: LineChart) {
        chart.description.isEnabled = false
        chart.setTouchEnabled(true)
        chart.isDragEnabled = true
        chart.setScaleEnabled(true)
        chart.setPinchZoom(true)
    }


    fun updatePredictions(futureBuy: List<FuturePrediction>) {
        val buyEntries = mutableListOf<Entry>()

        futureBuy.forEachIndexed { index, prediction ->
            prediction.value?.let { value ->
                buyEntries.add(Entry(index.toFloat(), value.toFloat()))
            }
        }

        val buyDataSet = LineDataSet(buyEntries, "Buy Predictions")
        buyDataSet.color = Color.parseColor("#4db5ff")
        buyDataSet.lineWidth = 2f

        buyChart?.let {
            it.data = LineData(buyDataSet)
            it.invalidate()
        }
    }

}
