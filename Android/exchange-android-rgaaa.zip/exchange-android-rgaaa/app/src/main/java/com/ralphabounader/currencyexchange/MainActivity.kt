package com.ralphabounader.currencyexchange

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
//import android.view.Menu
//import android.view.MenuItem
import android.view.View
import android.widget.RadioGroup
import android.widget.TextView
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.google.android.material.textfield.TextInputLayout
import com.ralphabounader.currencyexchange.api.Authentication
import com.ralphabounader.currencyexchange.api.ExchangeService
import com.ralphabounader.currencyexchange.api.model.ExchangeRates
import com.ralphabounader.currencyexchange.api.model.Transaction
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private var buyUsdTextView: TextView? = null
    private var sellUsdTextView: TextView? = null

    private var fab: FloatingActionButton? = null
    private var transactionDialog: View? = null

    private var menu: Menu? = null

    private var tabLayout: TabLayout? = null
    private var tabsViewPager: ViewPager2? = null

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        this.menu = menu
        setMenu()
        return true
    }
    private fun setMenu() {
        menu?.clear()
        menuInflater.inflate(if(Authentication.getToken() == null)
            R.menu.menu_logged_out else R.menu.menu_logged_in, menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.login) {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        } else if (item.itemId == R.id.register) {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
        } else if (item.itemId == R.id.logout) {
            Authentication.clearToken()
            setMenu()
        }
        return true
    }

    private fun addTransaction(transaction: Transaction) {
        val token = Authentication.getToken()
        if (token != null) {
            val authHeader = "Bearer $token"

            ExchangeService.exchangeApi().addTransaction(transaction, authHeader).enqueue(object : Callback<Any> {
                override fun onResponse(call: Call<Any>, response: Response<Any>) {
                    Snackbar.make(fab as View, "Transaction added!", Snackbar.LENGTH_LONG)
                        .show()
                }

                override fun onFailure(call: Call<Any>, t: Throwable) {
                    Snackbar.make(fab as View, "Could not add transaction.", Snackbar.LENGTH_LONG)
                        .show()
                }
            })
        } else {
            // Handle the case when the token is null
        }
    }


    private fun showDialog() {
        transactionDialog = LayoutInflater.from(this)
            .inflate(R.layout.dialog_transaction, null, false)
        MaterialAlertDialogBuilder(this).setView(transactionDialog)
            .setTitle("Add Transaction")
            .setMessage("Enter transaction details")
            .setPositiveButton("Add") { dialog, _ ->
                val usdAmounts =
                    transactionDialog?.findViewById<TextInputLayout>(R.id.txtInptUsdAmount)?.editText?.text.toString().toFloat()
                val lbpAmounts = transactionDialog?.findViewById<TextInputLayout>(R.id.txtInputLbpAmount)?.editText?.text.toString().toFloat()

                val transactionType = transactionDialog?.findViewById<RadioGroup>(R.id.rdGrpTransactionType)?.checkedRadioButtonId

                val usdToLbps: Boolean = when (transactionType) {
                    R.id.rdBtnBuyUsd -> true
                    else -> false
                }

                val transaction = Transaction().apply {
                    usdAmount = usdAmounts
                    lbpAmount = lbpAmounts
                    usdToLbp = usdToLbps
                }
                addTransaction(transaction)
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .show() }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //fetchRates()
        Authentication.initialize(this)
        setContentView(R.layout.activity_main)
        //buyUsdTextView = findViewById(R.id.txtBuyUsdRate)
        //sellUsdTextView = findViewById(R.id.txtSellUsdRate)
        tabLayout = findViewById(R.id.tabLayout)
        tabsViewPager = findViewById(R.id.tabsViewPager)
        tabLayout?.tabMode = TabLayout.MODE_FIXED
        tabLayout?.isInlineLabel = true
        tabsViewPager?.isUserInputEnabled = true
        val adapter = TabsPagerAdapter(supportFragmentManager, lifecycle)
        tabsViewPager?.adapter = adapter
        TabLayoutMediator(tabLayout!!, tabsViewPager!!) { tab, position ->
            when (position) {
                0 -> {
                    tab.text = "Exchange"
                }
                1 -> {
                    tab.text = "Transactions"
                }
            }
        }.attach()
        fab = findViewById(R.id.fab)
        fab?.setOnClickListener { view ->
            showDialog()
        }

    }




}