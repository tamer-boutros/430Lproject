package com.ralphabounader.currencyexchange

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ralphabounader.currencyexchange.api.Authentication
import com.ralphabounader.currencyexchange.api.ExchangeService
import com.ralphabounader.currencyexchange.api.model.Transaction
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class TransactionsFragment : Fragment() {

    private var recyclerView: RecyclerView? = null
    private var transactions: ArrayList<Transaction>? = ArrayList()
    private var adapter: TransactionAdapter? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fetchTransactions()

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View = inflater.inflate(R.layout.fragment_transactions,
            container, false)
        recyclerView = view.findViewById(R.id.recyclerViewTransactions)
        adapter = TransactionAdapter(transactions!!)
        recyclerView?.adapter = adapter
        recyclerView?.layoutManager = LinearLayoutManager(context)
        return view
    }

    class TransactionAdapter(private val dataSource: List<Transaction>) : RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val txtTransactionId: TextView = view.findViewById(R.id.txtTransactionId)
            val txtUsdAmount: TextView = view.findViewById(R.id.txtUsdAmount)
            val txtLbpAmount: TextView = view.findViewById(R.id.txtLbpAmount)
            val txtTransactionType: TextView = view.findViewById(R.id.txtTransactionType)
            val txtAddedDate: TextView = view.findViewById(R.id.txtAddedDate)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val transaction = dataSource[position]

            holder.txtTransactionId.text = "ID: ${transaction.id}"
            holder.txtUsdAmount.text = "USD Amount: ${transaction.usdAmount}"
            holder.txtLbpAmount.text = "LBP Amount: ${transaction.lbpAmount}"
            holder.txtTransactionType.text = if (transaction.usdToLbp == true) "USD to LBP" else "LBP to USD"
            holder.txtAddedDate.text = "Added Date: ${transaction.added_date}"
        }

        override fun getItemCount(): Int {
            return dataSource.size
        }
    }

    private fun fetchTransactions() {
        if (Authentication.getToken() != null) {
            ExchangeService.exchangeApi()
                .getTransactions("Bearer ${Authentication.getToken()}")
                .enqueue(object : Callback<List<Transaction>> {
                    override fun onFailure(call: Call<List<Transaction>>,
                                           t: Throwable) {
                        return
                    }
                    override fun onResponse(
                        call: Call<List<Transaction>>,
                        response: Response<List<Transaction>>
                    ) {
                        transactions?.addAll(response.body()!!)
                        adapter?.notifyDataSetChanged()
                    }
                })
        }
    }
}


